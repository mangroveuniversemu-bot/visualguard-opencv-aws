"""Replayable probe for REPLAY_LEDGER_POLICY_DIGEST001."""
from __future__ import annotations

import json
from pathlib import Path
import sqlite3
import tempfile

from vision.opencv5_inspection import (
    CaptureReplayLedger,
    CaptureReplayLedgerSchemaError,
    View,
    frame,
    inspect,
)


def inspection(ledger: CaptureReplayLedger) -> dict:
    return inspect(
        {
            "front": View(
                frame(False),
                source_id="camera-front-v1",
                capture_id="capture-front-policy-digest",
                captured_at=100.0,
            ),
            "side": View(
                frame(False),
                source_id="camera-side-v1",
                capture_id="capture-side-policy-digest",
                captured_at=100.0,
            ),
        },
        captured_at=100.0,
        now=101.0,
        replay_ledger=ledger,
    )


def main() -> None:
    with tempfile.TemporaryDirectory(prefix="policy-digest-probe-") as directory:
        root = Path(directory)
        path = root / "captures.sqlite3"
        with CaptureReplayLedger(path) as ledger:
            first = inspection(ledger)
            first_digest = ledger.policy_digest()
            first_rows = ledger.entry_count()

        with CaptureReplayLedger(path) as restarted:
            replay = inspection(restarted)
            restart_digest = restarted.policy_digest()
            with sqlite3.connect(path) as connection:
                connection.execute(
                    "UPDATE replay_ledger_policy "
                    "SET max_entries = max_entries + 1 "
                    "WHERE singleton = 1"
                )
            try:
                restarted.policy_digest()
            except CaptureReplayLedgerSchemaError as error:
                drift_digest_result = str(error)
            else:
                drift_digest_result = "UNEXPECTED_PASS"
            drifted = inspection(restarted)
            drift_rows = restarted.entry_count()

        with CaptureReplayLedger(
            root / "different.sqlite3", max_entries=10_001
        ) as different:
            different_digest = different.policy_digest()

        print(
            json.dumps(
                {
                    "first_decision": first["decision"],
                    "first_replay_status": first["evidence"][
                        "capture_replay_status"
                    ],
                    "first_digest": first_digest,
                    "first_evidence_digest": first["evidence"][
                        "capture_replay_policy_sha256"
                    ],
                    "first_rows": first_rows,
                    "restart_digest": restart_digest,
                    "restart_digest_matches": restart_digest == first_digest,
                    "replay_status": replay["evidence"][
                        "capture_replay_status"
                    ],
                    "replay_evidence_digest": replay["evidence"][
                        "capture_replay_policy_sha256"
                    ],
                    "different_policy_digest": different_digest,
                    "different_policy_digest_differs": (
                        different_digest != first_digest
                    ),
                    "drift_digest_result": drift_digest_result,
                    "drift_decision": drifted["decision"],
                    "drift_reason": drifted["reason"],
                    "drift_rows": drift_rows,
                },
                sort_keys=True,
            )
        )


if __name__ == "__main__":
    main()
