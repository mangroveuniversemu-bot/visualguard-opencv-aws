"""Replay an older valid ledger snapshot and evaluate an independent anchor."""
from __future__ import annotations

import hashlib
import json
from pathlib import Path
import shutil
import tempfile

from vision.opencv5_inspection import CaptureReplayLedger


def file_sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main() -> None:
    with tempfile.TemporaryDirectory(prefix="snapshot-rollback-falsifier-") as root:
        root_path = Path(root)
        ledger_path = root_path / "captures.sqlite3"
        old_snapshot = root_path / "older-valid.sqlite3"

        with CaptureReplayLedger(ledger_path) as ledger:
            first_status = ledger.check_and_record(
                {"capture-old": "a" * 64}
            )
            old_identity = ledger.rowset_identity()
        shutil.copy2(ledger_path, old_snapshot)
        old_database_sha256 = file_sha256(old_snapshot)

        with CaptureReplayLedger(ledger_path) as ledger:
            newest_status = ledger.check_and_record(
                {"capture-new": "b" * 64}
            )
            newest_identity = ledger.rowset_identity()
            newest_policy_sha256 = ledger.policy_digest()
            newest_capture_schema_sha256 = ledger.capture_schema_digest()
            newest_rowset_schema_sha256 = ledger.rowset_schema_digest()
        newest_database_sha256 = file_sha256(ledger_path)

        # This object deliberately lives outside the restored SQLite snapshot.
        # It models the minimum state an authorized monotonic anchor must retain.
        trusted_anchor = {
            "sequence": 2,
            "row_count": newest_identity["row_count"],
            "rowset_sha256": newest_identity["sha256"],
            "policy_sha256": newest_policy_sha256,
            "capture_schema_sha256": newest_capture_schema_sha256,
            "rowset_schema_sha256": newest_rowset_schema_sha256,
        }

        for suffix in ("-wal", "-shm"):
            sidecar = Path(f"{ledger_path}{suffix}")
            if sidecar.exists():
                sidecar.unlink()
        shutil.copy2(old_snapshot, ledger_path)
        restored_database_sha256 = file_sha256(ledger_path)

        with CaptureReplayLedger(ledger_path) as restored:
            restored_identity = restored.rowset_identity()
            replay_status = restored.check_and_record(
                {"capture-old": "a" * 64}
            )
            local_open_accepted = True

        external_anchor_verdict = (
            "ROLLBACK_DETECTED"
            if (
                restored_identity["row_count"]
                < trusted_anchor["row_count"]
                or restored_identity["sha256"]
                != trusted_anchor["rowset_sha256"]
            )
            else "CURRENT"
        )

        print(
            json.dumps(
                {
                    "external_anchor_mode": "TRUSTED_SIMULATION_ONLY",
                    "external_anchor_verdict": external_anchor_verdict,
                    "first_status": first_status,
                    "local_open_accepted": local_open_accepted,
                    "newest_database_sha256": newest_database_sha256,
                    "newest_identity": newest_identity,
                    "newest_status": newest_status,
                    "old_database_sha256": old_database_sha256,
                    "old_identity": old_identity,
                    "replay_status_after_restore": replay_status,
                    "restored_database_matches_old": (
                        restored_database_sha256 == old_database_sha256
                    ),
                    "restored_database_sha256": restored_database_sha256,
                    "restored_identity": restored_identity,
                    "trusted_anchor": trusted_anchor,
                },
                sort_keys=True,
            )
        )


if __name__ == "__main__":
    main()
