"""Replayable probe for REPLAY_LEDGER_CAPTURE_TABLE_SCHEMA_DIGEST001."""
from __future__ import annotations

import json
from pathlib import Path
import sqlite3
import tempfile

from vision.opencv5_inspection import (
    CaptureReplayLedger,
    CaptureReplayLedgerSchemaError,
    View,
    frame,
    inspect,
)


def inspection(ledger: CaptureReplayLedger) -> dict:
    return inspect(
        {
            "front": View(
                frame(False),
                source_id="camera-front-v1",
                capture_id="capture-front-schema-digest",
                captured_at=100.0,
            ),
            "side": View(
                frame(False),
                source_id="camera-side-v1",
                capture_id="capture-side-schema-digest",
                captured_at=100.0,
            ),
        },
        captured_at=100.0,
        now=101.0,
        replay_ledger=ledger,
    )


def weaken_capture_table(path: Path) -> None:
    with sqlite3.connect(path) as connection:
        connection.executescript(
            """
            ALTER TABLE capture_replay RENAME TO capture_replay_old;
            CREATE TABLE capture_replay (
                capture_id TEXT,
                envelope_schema_version INTEGER,
                envelope_sha256 TEXT,
                policy_sha256 TEXT
            );
            INSERT INTO capture_replay SELECT * FROM capture_replay_old;
            DROP TABLE capture_replay_old;
            """
        )


def rejected_open(path: Path) -> str:
    try:
        CaptureReplayLedger(path)
    except CaptureReplayLedgerSchemaError as error:
        return str(error)
    return "UNEXPECTED_PASS"


def main() -> None:
    with tempfile.TemporaryDirectory(prefix="capture-schema-probe-") as directory:
        root = Path(directory)
        path = root / "captures.sqlite3"
        with CaptureReplayLedger(path) as ledger:
            first = inspection(ledger)
            first_digest = ledger.capture_schema_digest()

        with CaptureReplayLedger(path) as restarted:
            replay = inspection(restarted)
            restart_digest = restarted.capture_schema_digest()
            with sqlite3.connect(path) as connection:
                connection.execute(
                    "ALTER TABLE capture_replay ADD COLUMN unbound TEXT"
                )
            drifted = inspection(restarted)
            drift_rows = restarted.entry_count()
        extra_column_restart = rejected_open(path)

        weak_path = root / "weak.sqlite3"
        with CaptureReplayLedger(weak_path) as ledger:
            inspection(ledger)
        weaken_capture_table(weak_path)
        weak_constraint_restart = rejected_open(weak_path)

        print(
            json.dumps(
                {
                    "drift_decision": drifted["decision"],
                    "drift_reason": drifted["reason"],
                    "drift_rows": drift_rows,
                    "evidence_digest": first["evidence"][
                        "capture_replay_schema_sha256"
                    ],
                    "extra_column_restart": extra_column_restart,
                    "first_digest": first_digest,
                    "first_replay_status": first["evidence"][
                        "capture_replay_status"
                    ],
                    "replay_status": replay["evidence"][
                        "capture_replay_status"
                    ],
                    "restart_digest": restart_digest,
                    "restart_digest_matches": restart_digest == first_digest,
                    "weak_constraint_restart": weak_constraint_restart,
                },
                sort_keys=True,
            )
        )


if __name__ == "__main__":
    main()
