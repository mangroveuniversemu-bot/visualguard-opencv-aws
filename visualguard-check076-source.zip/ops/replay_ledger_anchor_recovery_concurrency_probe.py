"""Replayable concurrency probe for DB-ahead anchor recovery."""
from __future__ import annotations

from concurrent.futures import ThreadPoolExecutor
import json
from pathlib import Path
import sys
import tempfile
import threading

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from vision.opencv5_inspection import (
    CaptureReplayAnchor,
    CaptureReplayAnchorState,
    CaptureReplayLedger,
)


class CoordinatedAnchor(CaptureReplayAnchor):
    """Atomic in-memory CAS with opt-in deterministic pause points."""

    def __init__(self) -> None:
        self.state: CaptureReplayAnchorState | None = None
        self._state_lock = threading.Lock()
        self.fail_next_cas = False
        self.cas_calls = 0
        self.successful_advances = 0
        self.recovery_barrier: threading.Barrier | None = None
        self.pause_after_advance = False
        self.anchor_advanced = threading.Event()
        self.release_advance = threading.Event()

    def read(self) -> CaptureReplayAnchorState | None:
        with self._state_lock:
            return self.state

    def compare_and_swap(
        self,
        expected: CaptureReplayAnchorState | None,
        replacement: CaptureReplayAnchorState,
    ) -> bool:
        self.cas_calls += 1
        if self.fail_next_cas:
            self.fail_next_cas = False
            return False
        if self.recovery_barrier is not None:
            self.recovery_barrier.wait(timeout=5)
        with self._state_lock:
            if self.state != expected:
                return False
            self.state = replacement
            self.successful_advances += 1
        if self.pause_after_advance:
            self.anchor_advanced.set()
            if not self.release_advance.wait(timeout=5):
                raise TimeoutError("recovery pause was not released")
        return True


def make_pending(path: Path, anchor: CoordinatedAnchor, capture_id: str):
    with CaptureReplayLedger(path, anchor=anchor) as ledger:
        anchor.fail_next_cas = True
        failed = ledger.check_and_record({capture_id: "a" * 64})
        receipt = ledger.pending_anchor_recovery_receipt()
    assert receipt is not None
    return failed, receipt


def concurrent_recovery(root: Path) -> dict[str, object]:
    path = root / "concurrent.sqlite3"
    anchor = CoordinatedAnchor()
    failed, receipt = make_pending(path, anchor, "capture-race")
    first = CaptureReplayLedger(path, anchor=anchor)
    second = CaptureReplayLedger(path, anchor=anchor)
    try:
        calls_before = anchor.cas_calls
        advances_before = anchor.successful_advances
        anchor.recovery_barrier = threading.Barrier(2)
        with ThreadPoolExecutor(max_workers=2) as pool:
            results = [
                future.result()
                for future in (
                    pool.submit(first.recover_anchor, receipt),
                    pool.submit(second.recover_anchor, receipt),
                )
            ]
        return {
            "anchor_sequence": anchor.state.sequence,
            "cas_attempts": anchor.cas_calls - calls_before,
            "failed_admission": failed,
            "pending_after": first.pending_anchor_recovery_receipt(),
            "statuses": sorted(result["status"] for result in results),
            "successful_advances": (
                anchor.successful_advances - advances_before
            ),
            "transition_ids": sorted(
                {result["transition_id"] for result in results}
            ),
        }
    finally:
        first.close()
        second.close()


def admission_interleaving(root: Path) -> dict[str, object]:
    path = root / "interleaving.sqlite3"
    anchor = CoordinatedAnchor()
    failed, receipt = make_pending(path, anchor, "capture-pending")
    recovering = CaptureReplayLedger(path, anchor=anchor)
    admitting = CaptureReplayLedger(path, anchor=anchor)
    anchor.pause_after_advance = True
    try:
        with ThreadPoolExecutor(max_workers=1) as pool:
            future = pool.submit(recovering.recover_anchor, receipt)
            if not anchor.anchor_advanced.wait(timeout=5):
                raise TimeoutError("anchor did not reach the pause point")
            pending_while_advanced = (
                admitting.pending_anchor_recovery_receipt() is not None
            )
            blocked = admitting.check_and_record(
                {"capture-blocked": "b" * 64}
            )
            anchor.release_advance.set()
            recovered = future.result()
        anchor.pause_after_advance = False
        admitted_after = admitting.check_and_record(
            {"capture-after-recovery": "c" * 64}
        )
        pending_after = admitting.pending_anchor_recovery_receipt()
    finally:
        anchor.release_advance.set()
        recovering.close()
        admitting.close()
    with CaptureReplayLedger(path, anchor=anchor) as restarted:
        restart = {
            "anchor_sequence": anchor.state.sequence,
            "row_count": restarted.entry_count(),
            "pending": restarted.pending_anchor_recovery_receipt(),
        }
    return {
        "admitted_after_recovery": admitted_after,
        "anchor_sequence_at_pause": 1,
        "blocked_while_marker_pending": blocked,
        "failed_admission": failed,
        "pending_after": pending_after,
        "pending_while_anchor_advanced": pending_while_advanced,
        "recovery_status": recovered["status"],
        "restart": restart,
    }


def main() -> None:
    with tempfile.TemporaryDirectory(
        prefix="anchor-recovery-concurrency-probe-"
    ) as root:
        root_path = Path(root)
        print(
            json.dumps(
                {
                    "admission_interleaving": admission_interleaving(
                        root_path
                    ),
                    "anchor_mode": "DETERMINISTIC_FIXTURE_ONLY",
                    "concurrent_recovery": concurrent_recovery(root_path),
                    "seed": "NONE",
                    "trusted_live_anchor": "NOT_RUN",
                },
                sort_keys=True,
            )
        )


if __name__ == "__main__":
    main()
