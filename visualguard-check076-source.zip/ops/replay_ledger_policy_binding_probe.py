"""Replayable probe for REPLAY_LEDGER_POLICY_BINDING001."""
from __future__ import annotations

import json
from pathlib import Path
import sqlite3
import tempfile

from vision.opencv5_inspection import (
    CaptureReplayLedger,
    CaptureReplayLedgerSchemaError,
)


BASELINE = {
    "max_entries": 17,
    "max_wal_backlog_frames": 19,
    "max_new_entries_per_batch": 3,
}


def main() -> None:
    with tempfile.TemporaryDirectory(prefix="policy-binding-probe-") as directory:
        path = Path(directory) / "ledger.sqlite3"
        with CaptureReplayLedger(path, **BASELINE) as ledger:
            first_write = ledger.check_and_record({
                "capture-policy-a": "a" * 64,
                "capture-policy-b": "b" * 64,
            })
            initial_policy = ledger.policy_evidence()

        with sqlite3.connect(path) as connection:
            persisted_row = connection.execute(
                "SELECT policy_schema_version, max_entries, "
                "max_wal_backlog_frames, max_new_entries_per_batch "
                "FROM replay_ledger_policy WHERE singleton = 1"
            ).fetchone()

        with CaptureReplayLedger(path, **BASELINE) as restarted:
            exact_replay = restarted.check_and_record({
                "capture-policy-a": "a" * 64,
                "capture-policy-b": "b" * 64,
            })
            restart_policy = restarted.policy_evidence()

        drift_results = {}
        for name, changed in (
            ("max_entries", 18),
            ("max_wal_backlog_frames", 20),
            ("max_new_entries_per_batch", 4),
        ):
            supplied = {**BASELINE, name: changed}
            try:
                CaptureReplayLedger(path, **supplied).close()
            except CaptureReplayLedgerSchemaError as error:
                drift_results[name] = str(error)
            else:
                drift_results[name] = "UNEXPECTED_ACCEPT"

        with CaptureReplayLedger(path, **BASELINE) as final:
            final_policy = final.policy_evidence()
            final_entries = final.entry_count()

        print(json.dumps({
            "first_write": list(first_write),
            "initial_policy": initial_policy,
            "persisted_row": list(persisted_row),
            "exact_replay": list(exact_replay),
            "restart_policy": restart_policy,
            "drift_results": drift_results,
            "final_policy": final_policy,
            "final_entries": final_entries,
        }, sort_keys=True))


if __name__ == "__main__":
    main()
