"""Replayable probe for REPLAY_LEDGER_POLICY_SCHEMA_DRIFT001."""
from __future__ import annotations

import json
from pathlib import Path
import sqlite3
import tempfile

from vision.opencv5_inspection import (
    CaptureReplayLedger,
    View,
    frame,
    inspect,
)


def replace_policy_table_without_constraints(path: Path) -> None:
    with sqlite3.connect(path) as connection:
        connection.executescript(
            """
            ALTER TABLE replay_ledger_policy
            RENAME TO replay_ledger_policy_old;
            CREATE TABLE replay_ledger_policy (
                singleton INTEGER,
                policy_schema_version INTEGER NOT NULL,
                max_entries INTEGER NOT NULL,
                max_wal_backlog_frames INTEGER NOT NULL,
                max_new_entries_per_batch INTEGER NOT NULL
            );
            INSERT INTO replay_ledger_policy
            SELECT * FROM replay_ledger_policy_old;
            DROP TABLE replay_ledger_policy_old;
            """
        )


def inspection(ledger: CaptureReplayLedger, suffix: str) -> dict:
    return inspect(
        {
            "front": View(
                frame(False),
                source_id="camera-front-v1",
                capture_id=f"capture-front-{suffix}",
                captured_at=100.0,
            ),
            "side": View(
                frame(False),
                source_id="camera-side-v1",
                capture_id=f"capture-side-{suffix}",
                captured_at=100.0,
            ),
        },
        captured_at=100.0,
        now=101.0,
        replay_ledger=ledger,
    )


def main() -> None:
    with tempfile.TemporaryDirectory(prefix="policy-schema-probe-") as directory:
        root = Path(directory)

        cardinality_path = root / "cardinality.sqlite3"
        with CaptureReplayLedger(cardinality_path) as ledger:
            replace_policy_table_without_constraints(cardinality_path)
            with sqlite3.connect(cardinality_path) as connection:
                connection.execute(
                    "INSERT INTO replay_ledger_policy "
                    "SELECT 2, policy_schema_version, max_entries, "
                    "max_wal_backlog_frames, max_new_entries_per_batch "
                    "FROM replay_ledger_policy WHERE singleton = 1"
                )
            cardinality_result = inspection(ledger, "cardinality")
            cardinality_rows = ledger.entry_count()

        primary_key_path = root / "primary-key.sqlite3"
        with CaptureReplayLedger(primary_key_path) as ledger:
            replace_policy_table_without_constraints(primary_key_path)
            primary_key_result = inspection(ledger, "primary-key")
            primary_key_rows = ledger.entry_count()

        column_path = root / "column.sqlite3"
        with CaptureReplayLedger(column_path) as ledger:
            with sqlite3.connect(column_path) as connection:
                connection.execute(
                    "ALTER TABLE replay_ledger_policy "
                    "ADD COLUMN unbound_policy TEXT"
                )
            column_result = inspection(ledger, "column")
            column_rows = ledger.entry_count()

        race_path = root / "race.sqlite3"
        with CaptureReplayLedger(race_path) as ledger:
            original = ledger._policy_schema_matches_unlocked
            schema_checks = 0

            def drift_after_first_schema_check() -> bool:
                nonlocal schema_checks
                matches = original()
                schema_checks += 1
                if schema_checks == 1:
                    replace_policy_table_without_constraints(race_path)
                return matches

            ledger._policy_schema_matches_unlocked = (
                drift_after_first_schema_check
            )
            statements = []
            ledger._connection.set_trace_callback(statements.append)
            race_result = ledger.check_and_record(
                {"capture-schema-race": "a" * 64}
            )
            ledger._connection.set_trace_callback(None)
            race_rows = ledger.entry_count()
            race_begin_count = sum(
                statement.lstrip().upper().startswith("BEGIN")
                for statement in statements
            )

        print(
            json.dumps(
                {
                    "cardinality_decision": cardinality_result["decision"],
                    "cardinality_reason": cardinality_result["reason"],
                    "cardinality_rows": cardinality_rows,
                    "primary_key_decision": primary_key_result["decision"],
                    "primary_key_reason": primary_key_result["reason"],
                    "primary_key_rows": primary_key_rows,
                    "column_decision": column_result["decision"],
                    "column_reason": column_result["reason"],
                    "column_rows": column_rows,
                    "race_result": list(race_result),
                    "race_schema_checks": schema_checks,
                    "race_begin_count": race_begin_count,
                    "race_rows": race_rows,
                },
                sort_keys=True,
            )
        )


if __name__ == "__main__":
    main()
