"""Replayable probe for REPLAY_LEDGER_CAPTURE_POLICY_BINDING001."""
from __future__ import annotations

import json
from pathlib import Path
import sqlite3
import tempfile

from vision.opencv5_inspection import (
    CaptureReplayLedger,
    CaptureReplayLedgerSchemaError,
    View,
    frame,
    inspect,
)


def inspection(ledger: CaptureReplayLedger) -> dict:
    return inspect(
        {
            "front": View(
                frame(False),
                source_id="camera-front-v1",
                capture_id="capture-front-policy-binding",
                captured_at=100.0,
            ),
            "side": View(
                frame(False),
                source_id="camera-side-v1",
                capture_id="capture-side-policy-binding",
                captured_at=100.0,
            ),
        },
        captured_at=100.0,
        now=101.0,
        replay_ledger=ledger,
    )


def main() -> None:
    with tempfile.TemporaryDirectory(prefix="capture-policy-probe-") as directory:
        root = Path(directory)
        path = root / "captures.sqlite3"
        with CaptureReplayLedger(path) as ledger:
            first = inspection(ledger)
            expected_policy = ledger.policy_digest()
            with sqlite3.connect(path) as connection:
                bound_rows = connection.execute(
                    "SELECT capture_id, policy_sha256 FROM capture_replay "
                    "ORDER BY capture_id"
                ).fetchall()

        with CaptureReplayLedger(path) as restarted:
            replay = inspection(restarted)
            with sqlite3.connect(path) as connection:
                connection.execute(
                    "UPDATE capture_replay SET policy_sha256 = ? "
                    "WHERE capture_id = ?",
                    ("b" * 64, "capture-front-policy-binding"),
                )
            drifted = inspection(restarted)
            drift_rows = restarted.entry_count()

        try:
            CaptureReplayLedger(path)
        except CaptureReplayLedgerSchemaError as error:
            restart_drift_result = str(error)
        else:
            restart_drift_result = "UNEXPECTED_PASS"

        print(
            json.dumps(
                {
                    "bound_row_count": len(bound_rows),
                    "bound_rows_match_policy": all(
                        policy == expected_policy for _, policy in bound_rows
                    ),
                    "drift_decision": drifted["decision"],
                    "drift_reason": drifted["reason"],
                    "drift_rows": drift_rows,
                    "first_decision": first["decision"],
                    "first_policy_digest": first["evidence"][
                        "capture_replay_policy_sha256"
                    ],
                    "first_replay_status": first["evidence"][
                        "capture_replay_status"
                    ],
                    "replay_status": replay["evidence"][
                        "capture_replay_status"
                    ],
                    "restart_drift_result": restart_drift_result,
                },
                sort_keys=True,
            )
        )


if __name__ == "__main__":
    main()
