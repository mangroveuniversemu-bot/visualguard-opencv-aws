"""Replayable fixture probe for proof-bound DB-ahead anchor recovery."""
from __future__ import annotations

import json
from pathlib import Path
import sys
import tempfile

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from vision.opencv5_inspection import (
    CaptureReplayAnchor,
    CaptureReplayAnchorState,
    CaptureReplayLedger,
    CaptureReplayLedgerAnchorError,
)


class FixtureAnchor(CaptureReplayAnchor):
    """Deterministic in-memory CAS provider; not a live trusted service."""

    def __init__(self) -> None:
        self.state: CaptureReplayAnchorState | None = None
        self.fail_next_cas = False
        self.cas_calls = 0

    def read(self) -> CaptureReplayAnchorState | None:
        return self.state

    def compare_and_swap(
        self,
        expected: CaptureReplayAnchorState | None,
        replacement: CaptureReplayAnchorState,
    ) -> bool:
        self.cas_calls += 1
        if self.fail_next_cas:
            self.fail_next_cas = False
            return False
        if self.state != expected:
            return False
        self.state = replacement
        return True


def error_code(action) -> str:
    try:
        action()
    except CaptureReplayLedgerAnchorError as error:
        return str(error)
    return "UNEXPECTED_PASS"


def main() -> None:
    with tempfile.TemporaryDirectory(prefix="anchor-recovery-probe-") as root:
        path = Path(root) / "replay.sqlite3"
        anchor = FixtureAnchor()

        with CaptureReplayLedger(path, anchor=anchor) as ledger:
            anchor.fail_next_cas = True
            failed_admission = ledger.check_and_record(
                {"capture-recover": "a" * 64}
            )
            receipt = ledger.pending_anchor_recovery_receipt()
            assert receipt is not None
            db_rows_after_failed_cas = ledger.entry_count()
            anchor_sequence_after_failed_cas = anchor.state.sequence

        with CaptureReplayLedger(path, anchor=anchor) as recovering:
            blocked_before_recovery = recovering.check_and_record(
                {"capture-blocked": "b" * 64}
            )
            tampered = json.loads(json.dumps(receipt))
            tampered["replacement"]["rowset_sha256"] = "f" * 64
            tamper_rejection = error_code(
                lambda: recovering.recover_anchor(tampered)
            )
            recovered = recovering.recover_anchor(receipt)
            exact_replay = recovering.check_and_record(
                {"capture-recover": "a" * 64}
            )
            stale_rejection = error_code(
                lambda: recovering.recover_anchor(receipt)
            )
            pending_after_recovery = (
                recovering.pending_anchor_recovery_receipt()
            )

        print(
            json.dumps(
                {
                    "anchor_mode": "DETERMINISTIC_FIXTURE_ONLY",
                    "anchor_sequence_after_failed_cas": (
                        anchor_sequence_after_failed_cas
                    ),
                    "anchor_sequence_after_recovery": anchor.state.sequence,
                    "blocked_before_recovery": blocked_before_recovery,
                    "cas_calls": anchor.cas_calls,
                    "db_rows_after_failed_cas": db_rows_after_failed_cas,
                    "exact_replay": exact_replay,
                    "failed_admission": failed_admission,
                    "pending_after_recovery": pending_after_recovery,
                    "receipt_sha256": receipt["receipt_sha256"],
                    "recovered": recovered,
                    "stale_rejection": stale_rejection,
                    "tamper_rejection": tamper_rejection,
                    "transition_id": receipt["transition_id"],
                    "trusted_live_anchor": "NOT_RUN",
                },
                sort_keys=True,
            )
        )


if __name__ == "__main__":
    main()
