"""Replayable probe for REPLAY_LEDGER_POLICY_RUNTIME_DRIFT001."""
from __future__ import annotations

import json
from pathlib import Path
import sqlite3
import tempfile

from vision.opencv5_inspection import (
    CaptureReplayLedger,
    View,
    frame,
    inspect,
)


def inspection(ledger: CaptureReplayLedger) -> dict:
    return inspect(
        {
            "front": View(
                frame(False), source_id="camera-front-v1",
                capture_id="capture-front-runtime", captured_at=100.0,
            ),
            "side": View(
                frame(False), source_id="camera-side-v1",
                capture_id="capture-side-runtime", captured_at=100.0,
            ),
        },
        captured_at=100.0,
        now=101.0,
        replay_ledger=ledger,
    )


def main() -> None:
    with tempfile.TemporaryDirectory(prefix="policy-runtime-probe-") as directory:
        root = Path(directory)
        value_path = root / "value.sqlite3"
        with CaptureReplayLedger(value_path) as ledger:
            initial = inspection(ledger)
            with sqlite3.connect(value_path) as connection:
                connection.execute(
                    "UPDATE replay_ledger_policy "
                    "SET max_entries = max_entries + 1 WHERE singleton = 1"
                )
            drifted = inspection(ledger)
            rows_during_drift = ledger.entry_count()
            with sqlite3.connect(value_path) as connection:
                connection.execute(
                    "UPDATE replay_ledger_policy SET max_entries = ? "
                    "WHERE singleton = 1",
                    (ledger.max_entries,),
                )
            restored = inspection(ledger)

        race_path = root / "race.sqlite3"
        with CaptureReplayLedger(race_path) as ledger:
            original = ledger._policy_evidence_unlocked
            policy_reads = 0

            def mutate_after_first_policy_read():
                nonlocal policy_reads
                evidence = original()
                policy_reads += 1
                if policy_reads == 1:
                    with sqlite3.connect(race_path) as connection:
                        connection.execute(
                            "UPDATE replay_ledger_policy "
                            "SET max_new_entries_per_batch = "
                            "max_new_entries_per_batch + 1 "
                            "WHERE singleton = 1"
                        )
                return evidence

            ledger._policy_evidence_unlocked = mutate_after_first_policy_read
            statements = []
            ledger._connection.set_trace_callback(statements.append)
            race_result = ledger.check_and_record({
                "capture-policy-race": "a" * 64
            })
            ledger._connection.set_trace_callback(None)
            race_rows = ledger.entry_count()
            race_begin_count = sum(
                statement.lstrip().upper().startswith("BEGIN")
                for statement in statements
            )

        missing_path = root / "missing.sqlite3"
        with CaptureReplayLedger(missing_path) as ledger:
            with sqlite3.connect(missing_path) as connection:
                connection.execute("DROP TABLE replay_ledger_policy")
            missing_result = ledger.check_and_record({
                "capture-policy-missing": "b" * 64
            })
            missing_rows = ledger.entry_count()

        print(json.dumps({
            "initial_decision": initial["decision"],
            "initial_replay_status": initial["evidence"][
                "capture_replay_status"
            ],
            "drift_decision": drifted["decision"],
            "drift_reason": drifted["reason"],
            "rows_during_drift": rows_during_drift,
            "restored_decision": restored["decision"],
            "restored_replay_status": restored["evidence"][
                "capture_replay_status"
            ],
            "race_result": list(race_result),
            "race_policy_reads": policy_reads,
            "race_begin_count": race_begin_count,
            "race_rows": race_rows,
            "missing_result": list(missing_result),
            "missing_rows": missing_rows,
        }, sort_keys=True))


if __name__ == "__main__":
    main()
