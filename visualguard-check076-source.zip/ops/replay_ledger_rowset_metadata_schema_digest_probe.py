"""Replayable probe for REPLAY_LEDGER_ROWSET_METADATA_SCHEMA_DIGEST001."""
from __future__ import annotations

import json
from pathlib import Path
import sqlite3
import tempfile

from vision.opencv5_inspection import (
    CaptureReplayLedger,
    CaptureReplayLedgerIntegrityError,
    CaptureReplayLedgerSchemaError,
    View,
    frame,
    inspect,
)


def views() -> dict[str, View]:
    return {
        "front": View(
            frame(False), source_id="camera-front-v1",
            capture_id="capture-front-schema", captured_at=100.0,
        ),
        "side": View(
            frame(False), source_id="camera-side-v1",
            capture_id="capture-side-schema", captured_at=100.0,
        ),
    }


def inspection(ledger: CaptureReplayLedger) -> dict:
    return inspect(
        views(), captured_at=100.0, now=101.0, replay_ledger=ledger
    )


def replace_rowset_table_without_constraints(
    path: Path, *, duplicate: bool = False
) -> None:
    with sqlite3.connect(path) as connection:
        connection.executescript(
            """
            ALTER TABLE replay_ledger_rowset
            RENAME TO replay_ledger_rowset_old;
            CREATE TABLE replay_ledger_rowset (
                singleton INTEGER,
                rowset_schema_version INTEGER,
                row_count INTEGER,
                rowset_sha256 TEXT
            );
            INSERT INTO replay_ledger_rowset
            SELECT * FROM replay_ledger_rowset_old;
            DROP TABLE replay_ledger_rowset_old;
            """
        )
        if duplicate:
            connection.execute(
                "INSERT INTO replay_ledger_rowset "
                "SELECT * FROM replay_ledger_rowset"
            )


def rejected_open(path: Path) -> str:
    try:
        CaptureReplayLedger(path)
    except (CaptureReplayLedgerIntegrityError,
            CaptureReplayLedgerSchemaError) as error:
        return str(error)
    return "UNEXPECTED_PASS"


def main() -> None:
    with tempfile.TemporaryDirectory(prefix="rowset-schema-probe-") as root:
        root_path = Path(root)
        valid_path = root_path / "valid.sqlite3"
        with CaptureReplayLedger(valid_path) as ledger:
            first = inspection(ledger)
            first_schema = ledger.rowset_schema_identity()

        with CaptureReplayLedger(valid_path) as restarted:
            restart_schema = restarted.rowset_schema_identity()

        runtime_ledger = CaptureReplayLedger(valid_path)
        try:
            rows_before = runtime_ledger.entry_count()
            with sqlite3.connect(valid_path) as connection:
                connection.execute(
                    "ALTER TABLE replay_ledger_rowset "
                    "ADD COLUMN attacker_note TEXT"
                )
            runtime_drift = inspection(runtime_ledger)
            rows_after = runtime_ledger.entry_count()
        finally:
            runtime_ledger.close()

        weakened_path = root_path / "weakened.sqlite3"
        with CaptureReplayLedger(weakened_path) as ledger:
            inspection(ledger)
        replace_rowset_table_without_constraints(weakened_path)

        duplicate_path = root_path / "duplicate.sqlite3"
        with CaptureReplayLedger(duplicate_path) as ledger:
            inspection(ledger)
        replace_rowset_table_without_constraints(duplicate_path, duplicate=True)

        print(
            json.dumps(
                {
                    "duplicate_restart": rejected_open(duplicate_path),
                    "first_decision": first["decision"],
                    "inspection_schema_digest": first["evidence"][
                        "capture_replay_rowset_schema_sha256"
                    ],
                    "restart_digest_stable": restart_schema == first_schema,
                    "rowset_schema_identity": first_schema,
                    "runtime_drift_decision": runtime_drift["decision"],
                    "runtime_drift_reason": runtime_drift["reason"],
                    "runtime_rows_unchanged": rows_before == rows_after,
                    "weakened_restart": rejected_open(weakened_path),
                },
                sort_keys=True,
            )
        )


if __name__ == "__main__":
    main()
