"""Replay the crash after anchor advance and before marker clearance."""
from __future__ import annotations

import json
from pathlib import Path
import sqlite3
import sys
import tempfile

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from vision.opencv5_inspection import (
    CaptureReplayAnchor,
    CaptureReplayAnchorState,
    CaptureReplayLedger,
    CaptureReplayLedgerAnchorError,
)


class CrashFixtureAnchor(CaptureReplayAnchor):
    """Deterministic in-memory anchor; not a live trusted provider."""

    def __init__(self) -> None:
        self.state: CaptureReplayAnchorState | None = None
        self.fail_next_cas = False

    def read(self) -> CaptureReplayAnchorState | None:
        return self.state

    def compare_and_swap(
        self,
        expected: CaptureReplayAnchorState | None,
        replacement: CaptureReplayAnchorState,
    ) -> bool:
        if self.fail_next_cas:
            self.fail_next_cas = False
            return False
        if self.state != expected:
            return False
        self.state = replacement
        return True


def make_pending(path: Path, capture_id: str):
    anchor = CrashFixtureAnchor()
    with CaptureReplayLedger(path, anchor=anchor) as ledger:
        anchor.fail_next_cas = True
        failed = ledger.check_and_record({capture_id: "a" * 64})
        receipt = ledger.pending_anchor_recovery_receipt()
    assert receipt is not None
    return anchor, failed, receipt


def marker_count(path: Path) -> int:
    with sqlite3.connect(path) as connection:
        return int(
            connection.execute(
                "SELECT COUNT(*) FROM replay_ledger_anchor_transition"
            ).fetchone()[0]
        )


def exact_restart(root: Path) -> dict[str, object]:
    path = root / "exact.sqlite3"
    anchor, failed, receipt = make_pending(path, "capture-exact")
    anchor.state = CaptureReplayLedger._anchor_state_from_dict(
        receipt["replacement"]
    )
    before = marker_count(path)
    with CaptureReplayLedger(path, anchor=anchor) as restarted:
        after = marker_count(path)
        replay = restarted.check_and_record({"capture-exact": "a" * 64})
        pending = restarted.pending_anchor_recovery_receipt()
    with CaptureReplayLedger(path, anchor=anchor) as second_restart:
        durable_after_second_restart = (
            second_restart.pending_anchor_recovery_receipt() is None
            and second_restart.entry_count() == 1
        )
    return {
        "anchor_sequence": anchor.state.sequence,
        "failed_admission": failed,
        "marker_after_restart": after,
        "marker_before_restart": before,
        "marker_clear_durable": durable_after_second_restart,
        "pending_after_restart": pending,
        "replay_after_restart": replay,
        "transition_id": receipt["transition_id"],
    }


def mismatched_marker_restart(root: Path) -> dict[str, object]:
    path = root / "marker-mismatch.sqlite3"
    anchor, _, receipt = make_pending(path, "capture-marker-mismatch")
    local_state = CaptureReplayLedger._anchor_state_from_dict(
        receipt["replacement"]
    )
    anchor.state = local_state
    wrong_replacement = CaptureReplayAnchorState(
        sequence=local_state.sequence,
        rowset_sha256="f" * 64,
        policy_sha256=local_state.policy_sha256,
        capture_schema_sha256=local_state.capture_schema_sha256,
        rowset_schema_sha256=local_state.rowset_schema_sha256,
    )
    wrong_receipt = CaptureReplayLedger._make_anchor_recovery_receipt(
        CaptureReplayLedger._anchor_state_from_dict(receipt["expected"]),
        wrong_replacement,
    )
    with sqlite3.connect(path) as connection:
        connection.execute(
            "UPDATE replay_ledger_anchor_transition SET "
            "transition_id = ?, receipt_json = ?, receipt_sha256 = ? "
            "WHERE singleton = 1",
            (
                wrong_receipt["transition_id"],
                json.dumps(
                    wrong_receipt, sort_keys=True, separators=(",", ":")
                ),
                wrong_receipt["receipt_sha256"],
            ),
        )
    try:
        CaptureReplayLedger(path, anchor=anchor)
    except CaptureReplayLedgerAnchorError as error:
        result = str(error)
    else:
        raise AssertionError("mismatched marker restart unexpectedly opened")
    return {
        "error": result,
        "marker_preserved": marker_count(path) == 1,
        "replacement_matches_local": False,
    }


def partial_anchor_restart(root: Path) -> dict[str, object]:
    path = root / "partial-anchor.sqlite3"
    anchor, _, receipt = make_pending(path, "capture-partial-anchor")
    local_state = CaptureReplayLedger._anchor_state_from_dict(
        receipt["replacement"]
    )
    anchor.state = CaptureReplayAnchorState(
        sequence=local_state.sequence,
        rowset_sha256=local_state.rowset_sha256,
        policy_sha256="f" * 64,
        capture_schema_sha256=local_state.capture_schema_sha256,
        rowset_schema_sha256=local_state.rowset_schema_sha256,
    )
    try:
        CaptureReplayLedger(path, anchor=anchor)
    except CaptureReplayLedgerAnchorError as error:
        result = str(error)
    else:
        raise AssertionError("partial anchor restart unexpectedly opened")
    return {
        "error": result,
        "marker_preserved": marker_count(path) == 1,
        "same_sequence": anchor.state.sequence == local_state.sequence,
    }


def main() -> None:
    with tempfile.TemporaryDirectory(
        prefix="anchor-post-advance-crash-probe-"
    ) as temp_dir:
        root = Path(temp_dir)
        print(
            json.dumps(
                {
                    "anchor_mode": "DETERMINISTIC_CRASH_FIXTURE_ONLY",
                    "exact_restart": exact_restart(root),
                    "mismatched_marker_restart": mismatched_marker_restart(
                        root
                    ),
                    "partial_anchor_restart": partial_anchor_restart(root),
                    "seed": "NONE",
                    "trusted_live_anchor": "NOT_RUN",
                },
                sort_keys=True,
            )
        )


if __name__ == "__main__":
    main()
