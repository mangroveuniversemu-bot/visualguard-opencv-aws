"""Fault-inject pending-anchor marker clearance and verify safe retry."""
from __future__ import annotations

import json
from pathlib import Path
import sqlite3
import sys
import tempfile

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from vision.opencv5_inspection import (
    CaptureReplayAnchor,
    CaptureReplayAnchorState,
    CaptureReplayLedger,
    CaptureReplayLedgerAnchorError,
)


class FaultFixtureAnchor(CaptureReplayAnchor):
    """Deterministic in-memory CAS; not a live trusted anchor."""

    def __init__(self) -> None:
        self.state: CaptureReplayAnchorState | None = None
        self.fail_next_cas = False

    def read(self) -> CaptureReplayAnchorState | None:
        return self.state

    def compare_and_swap(
        self,
        expected: CaptureReplayAnchorState | None,
        replacement: CaptureReplayAnchorState,
    ) -> bool:
        if self.fail_next_cas:
            self.fail_next_cas = False
            return False
        if self.state != expected:
            return False
        self.state = replacement
        return True


def install_clear_fault(path: Path) -> None:
    with sqlite3.connect(path) as connection:
        connection.execute(
            "CREATE TRIGGER fail_anchor_marker_clear "
            "BEFORE DELETE ON replay_ledger_anchor_transition "
            "BEGIN SELECT RAISE(ABORT, 'marker clear fault'); END"
        )


def remove_clear_fault(path: Path) -> None:
    with sqlite3.connect(path) as connection:
        connection.execute("DROP TRIGGER fail_anchor_marker_clear")


def marker_count(path: Path) -> int:
    with sqlite3.connect(path) as connection:
        return int(
            connection.execute(
                "SELECT COUNT(*) FROM replay_ledger_anchor_transition"
            ).fetchone()[0]
        )


def startup_retry(root: Path) -> dict[str, object]:
    path = root / "startup-retry.sqlite3"
    anchor = FaultFixtureAnchor()
    ledger = CaptureReplayLedger(path, anchor=anchor)
    anchor.fail_next_cas = True
    failed = ledger.check_and_record({"capture-startup-retry": "a" * 64})
    receipt = ledger.pending_anchor_recovery_receipt()
    assert receipt is not None
    anchor.state = CaptureReplayLedger._anchor_state_from_dict(
        receipt["replacement"]
    )
    install_clear_fault(path)
    blocked = ledger.check_and_record({"capture-blocked": "b" * 64})
    ledger.close()

    attempts = []
    for _ in range(2):
        try:
            CaptureReplayLedger(path, anchor=anchor)
        except CaptureReplayLedgerAnchorError as error:
            attempts.append(
                {"error": str(error), "marker_count": marker_count(path)}
            )
        else:
            raise AssertionError("faulted startup unexpectedly opened")

    remove_clear_fault(path)
    with CaptureReplayLedger(path, anchor=anchor) as restarted:
        recovered = {
            "marker_count": marker_count(path),
            "pending": restarted.pending_anchor_recovery_receipt(),
            "replay": restarted.check_and_record(
                {"capture-startup-retry": "a" * 64}
            ),
        }
    with CaptureReplayLedger(path, anchor=anchor) as second_restart:
        durable = {
            "marker_count": marker_count(path),
            "pending": second_restart.pending_anchor_recovery_receipt(),
            "row_count": second_restart.entry_count(),
        }
    return {
        "admission_while_marker_pending": blocked,
        "failed_initial_admission": failed,
        "faulted_restart_attempts": attempts,
        "recovered_restart": recovered,
        "second_restart": durable,
    }


def explicit_recovery_retry(root: Path) -> dict[str, object]:
    path = root / "explicit-recovery.sqlite3"
    anchor = FaultFixtureAnchor()
    with CaptureReplayLedger(path, anchor=anchor) as ledger:
        anchor.fail_next_cas = True
        ledger.check_and_record({"capture-explicit-retry": "a" * 64})
        receipt = ledger.pending_anchor_recovery_receipt()
        assert receipt is not None
        install_clear_fault(path)
        errors = []
        for _ in range(2):
            try:
                ledger.recover_anchor(receipt)
            except CaptureReplayLedgerAnchorError as error:
                errors.append(str(error))
            else:
                raise AssertionError("faulted recovery unexpectedly cleared")
        while_faulted = {
            "admission": ledger.check_and_record(
                {"capture-blocked": "b" * 64}
            ),
            "anchor_sequence": anchor.state.sequence,
            "errors": errors,
            "marker_count": marker_count(path),
        }
        remove_clear_fault(path)
    with CaptureReplayLedger(path, anchor=anchor) as restarted:
        after_storage_recovery = {
            "anchor_sequence": anchor.state.sequence,
            "marker_count": marker_count(path),
            "pending": restarted.pending_anchor_recovery_receipt(),
            "row_count": restarted.entry_count(),
        }
    return {
        "after_storage_recovery": after_storage_recovery,
        "while_faulted": while_faulted,
    }


def main() -> None:
    with tempfile.TemporaryDirectory(
        prefix="anchor-marker-clear-failure-probe-"
    ) as temp_dir:
        root = Path(temp_dir)
        print(
            json.dumps(
                {
                    "anchor_mode": "DETERMINISTIC_FAULT_FIXTURE_ONLY",
                    "explicit_recovery_retry": explicit_recovery_retry(root),
                    "seed": "NONE",
                    "startup_retry": startup_retry(root),
                    "trusted_live_anchor": "NOT_RUN",
                },
                sort_keys=True,
            )
        )


if __name__ == "__main__":
    main()
