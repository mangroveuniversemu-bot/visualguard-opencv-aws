"""Replayable probe for REPLAY_LEDGER_ROWSET_COMMITMENT001."""
from __future__ import annotations

import json
from pathlib import Path
import sqlite3
import tempfile

from vision.opencv5_inspection import (
    CaptureReplayLedger,
    CaptureReplayLedgerIntegrityError,
)


ENTRIES = {
    "capture-front-rowset": "a" * 64,
    "capture-side-rowset": "b" * 64,
}


def rejected_open(path: Path) -> str:
    try:
        CaptureReplayLedger(path)
    except CaptureReplayLedgerIntegrityError as error:
        return str(error)
    return "UNEXPECTED_PASS"


def main() -> None:
    with tempfile.TemporaryDirectory(prefix="rowset-commitment-probe-") as root:
        path = Path(root) / "captures.sqlite3"
        with CaptureReplayLedger(path) as ledger:
            first_status = ledger.check_and_record(ENTRIES)
            first_identity = ledger.rowset_identity()

        with CaptureReplayLedger(path) as restarted:
            replay_status = restarted.check_and_record(ENTRIES)
            restart_identity = restarted.rowset_identity()

        ledger = CaptureReplayLedger(path)
        try:
            with sqlite3.connect(path) as connection:
                connection.execute(
                    "DELETE FROM capture_replay WHERE capture_id = ?",
                    ("capture-side-rowset",),
                )
            drift_status = ledger.check_and_record(ENTRIES)
            remaining_rows = ledger.entry_count()
        finally:
            ledger.close()

        print(
            json.dumps(
                {
                    "drift_status": drift_status,
                    "first_identity": first_identity,
                    "first_status": first_status,
                    "remaining_rows": remaining_rows,
                    "restart_after_delete": rejected_open(path),
                    "restart_digest_matches": restart_identity == first_identity,
                    "restart_identity": restart_identity,
                    "restart_status": replay_status,
                },
                sort_keys=True,
            )
        )


if __name__ == "__main__":
    main()
