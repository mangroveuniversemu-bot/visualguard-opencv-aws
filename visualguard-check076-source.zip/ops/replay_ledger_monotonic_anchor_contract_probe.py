"""Replayable fixture probe for the monotonic replay-anchor contract."""
from __future__ import annotations

import json
from pathlib import Path
import shutil
import sys
import tempfile

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from vision.opencv5_inspection import (
    CaptureReplayAnchor,
    CaptureReplayAnchorState,
    CaptureReplayLedger,
    CaptureReplayLedgerAnchorError,
)


class FixtureAnchor(CaptureReplayAnchor):
    """Deterministic in-memory CAS provider; not a live trusted service."""

    def __init__(self) -> None:
        self.state: CaptureReplayAnchorState | None = None
        self.fail_next_cas = False
        self.cas_calls = 0

    def read(self) -> CaptureReplayAnchorState | None:
        return self.state

    def compare_and_swap(
        self,
        expected: CaptureReplayAnchorState | None,
        replacement: CaptureReplayAnchorState,
    ) -> bool:
        self.cas_calls += 1
        if self.fail_next_cas:
            self.fail_next_cas = False
            return False
        if self.state != expected:
            return False
        self.state = replacement
        return True


def rejected_open(path: Path, anchor: FixtureAnchor) -> str:
    try:
        CaptureReplayLedger(path, anchor=anchor)
    except CaptureReplayLedgerAnchorError as error:
        return str(error)
    return "UNEXPECTED_PASS"


def main() -> None:
    with tempfile.TemporaryDirectory(prefix="monotonic-anchor-probe-") as root:
        root_path = Path(root)

        crash_path = root_path / "crash-window.sqlite3"
        crash_anchor = FixtureAnchor()
        with CaptureReplayLedger(crash_path, anchor=crash_anchor) as ledger:
            bootstrap = ledger.anchor_evidence()
            first_status = ledger.check_and_record({"capture-1": "a" * 64})
            after_first = ledger.anchor_evidence()
            crash_anchor.fail_next_cas = True
            failed_cas_status = ledger.check_and_record(
                {"capture-2": "b" * 64}
            )
            committed_rows_after_failed_cas = ledger.entry_count()
            anchor_sequence_after_failed_cas = crash_anchor.state.sequence
        crash_window_restart = rejected_open(crash_path, crash_anchor)

        snapshot_path = root_path / "snapshot.sqlite3"
        old_snapshot = root_path / "older-valid.sqlite3"
        snapshot_anchor = FixtureAnchor()
        with CaptureReplayLedger(snapshot_path, anchor=snapshot_anchor) as ledger:
            ledger.check_and_record({"capture-old": "c" * 64})
        shutil.copy2(snapshot_path, old_snapshot)
        with CaptureReplayLedger(snapshot_path, anchor=snapshot_anchor) as ledger:
            ledger.check_and_record({"capture-new": "d" * 64})
            newest_anchor = ledger.anchor_evidence()
        for suffix in ("-wal", "-shm"):
            sidecar = Path(f"{snapshot_path}{suffix}")
            if sidecar.exists():
                sidecar.unlink()
        shutil.copy2(old_snapshot, snapshot_path)
        rollback_restart = rejected_open(snapshot_path, snapshot_anchor)

        print(
            json.dumps(
                {
                    "anchor_mode": "DETERMINISTIC_FIXTURE_ONLY",
                    "anchor_sequence_after_failed_cas": (
                        anchor_sequence_after_failed_cas
                    ),
                    "bootstrap": bootstrap,
                    "cas_calls": crash_anchor.cas_calls,
                    "committed_rows_after_failed_cas": (
                        committed_rows_after_failed_cas
                    ),
                    "crash_window_restart": crash_window_restart,
                    "failed_cas_status": failed_cas_status,
                    "first_anchor": after_first,
                    "first_status": first_status,
                    "newest_snapshot_anchor": newest_anchor,
                    "restored_snapshot_restart": rollback_restart,
                    "trusted_live_anchor": "NOT_RUN",
                },
                sort_keys=True,
            )
        )


if __name__ == "__main__":
    main()
