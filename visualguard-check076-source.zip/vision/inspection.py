"""Synthetic pixel fixture with a generic inspection decision.

Pure Python CPU implementation, not OpenCV 5, a camera or a safety controller.
"""
from __future__ import annotations

import hashlib


def frame(alarm: bool) -> list[list[int]]:
    image = [[0] * 24 for _ in range(16)]
    for y in range(4, 12):
        for x in range(8, 16):
            image[y][x] = 255 if alarm else 32
    return image


def frame_hash(image) -> str:
    return hashlib.sha256(bytes(v for row in image for v in row)).hexdigest()


def observe(image) -> dict:
    if (len(image) != 16 or any(len(row) != 24 for row in image)
            or any(type(v) is not int or not 0 <= v <= 255 for row in image for v in row)):
        raise ValueError("INVALID_FRAME")
    bright = sum(image[y][x] >= 200 for y in range(4, 12) for x in range(8, 16))
    return {"bright_pixels": bright, "alarm": bright >= 32, "frame_sha256": frame_hash(image)}


def inspect(views: dict, *, captured_at: float, now: float, model: str = "fixture-v1",
            calibrated: bool = True) -> dict:
    if now < captured_at or now - captured_at > 5:
        return {"decision": "STOP", "reason": "STALE_OR_FUTURE_FRAME"}
    if not calibrated or model != "fixture-v1":
        return {"decision": "STOP", "reason": "CALIBRATION_OR_MODEL_CHANGED"}
    if set(views) != {"front", "side"}:
        return {"decision": "REQUEST_VIEW", "reason": "INCOMPLETE_COVERAGE"}
    try:
        observations = {k: observe(v) for k, v in views.items()}
    except (ValueError, TypeError):
        return {"decision": "STOP", "reason": "INVALID_FRAME"}
    return {"decision": "STOP" if any(o["alarm"] for o in observations.values()) else "REVIEW",
            "reason": "ALARM" if any(o["alarm"] for o in observations.values()) else "HUMAN_REVIEW",
            "observations": observations, "physical_action": "NONE"}


def verify_effect(expected_alarm: bool, observed_image) -> dict:
    result = observe(observed_image)
    return {"closure": "MATCH" if result["alarm"] == expected_alarm else "MISMATCH",
            "observed": result, "physical_action": "NONE"}
