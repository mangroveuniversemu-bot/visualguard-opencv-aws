# Final review status

This page is the current human-readable status for the final-review source archive, prepared on 27 October 2026. It is an editorial update to the prior local review candidate. No application, test, deployment configuration or bound evidence bytes were changed for this packaging step.

## Current evidence

**Private AWS execution is complete.** The Lambda container ran in us-east-1 with AWS_IAM access from source `832b1b476ce88e3fa95e83ac5749f64af0f4bd63`. The recorded cases are health, synthetic side-only alarm, synthetic clear views and empty views. The receipt is `evidence/AWS_EXECUTION_20261026_40223113044.json`; workflow run 40223113044 and the supplemental Console event support it. The first three calls retain summaries and REPORT lines, while the supplemental call retains a full response. Durations are not a per-case latency benchmark.

**Repository baseline and local candidate are distinct.** The baseline is `b85ebb0873cf030ab95fd32c1d886df59bf74c86`; saved hosted CI run 40249719964 reports 268 tests and 116 subtests passed. The prior local Windows review candidate includes fixture closure, writable temporary-directory support and path formatting fixes. Its saved result is 266 tests passed, 2 POSIX-only skips and 116 subtests passed. Those local changes have not been pushed, remotely CI-verified or redeployed. This archive retains them without further program changes.

**Archived real-image exploration is complete locally.** Twelve frames from four exhibition videos and three photographs were processed using the OpenCV 5 inspection module. None produced red candidates; one manual crop of one photo also produced none. The 15 images have no machine-alarm ground-truth labels and are not 15 independent machine trials. Therefore no real-world alarm accuracy or recall is reported. This exploration is separate from live-camera integration and from the synthetic AWS calls. The companion records are `real-camera-local-analysis.json` and `manual-roi-comparison.json`.

**The edited movie is a separate companion artifact.** `VisualGuard-YOUNG-FU-final-review.mp4` is supplied with the final review package, alongside its current script, captions, media checks and package manifest. It combines archived real exhibition context, labelled AI-generated illustrative operator scenes, local application captures with synthetic input, and saved AWS records. The actor is illustrative; the entrant is YOUNG-FU. Use the companion package manifest for the current movie hash and owner-review status.

**Technical limits remain explicit.** Live-camera integration, field accuracy and physical actuation are not established. Planned actions are returned without an actuator call. The replay ledger is scoped to a process or Lambda execution environment. Thirty round red sticker cases falsely trigger STOP; one synthetic motion-blur case returns REVIEW instead of REQUEST_VIEW. The 540-pair synthetic exact-decision result is 94.26%; no alarm-containing case in the 210-case subset returned REVIEW, which is not equivalent to detecting every alarm.

## How to read older statuses

The files below are preserved as evidence of their original checkpoint, including their original timestamps and hashes:

- `deployment.json` contains historical validation, capture-contract and video-gate states. Its `stage` remains compatible with the deployment preflight, while `aws_execution_evidence` records the completed private deployment. Older prepared-video fields are not a status probe of the separate edited final-review movie.
- `evidence/VISUALGUARD_DEMO_EVIDENCE_CONTRACT001.json`, `evidence/VISUALGUARD_AWS_DEMO_CAPTURE_PACKET002.json` and the checked-in storyboard describe a prior six-segment, 180-second prepared capture contract. The new edited movie is not silently declared to have passed that old contract's human-attestation gate.
- `evidence/VISUALGUARD_JUDGE_EVIDENCE_INDEX001.json` (CHECK146) validates six bound artifacts, four AWS cases and eight local negative controls. Its historical `PREPARED_NOT_RECORDED` status does not invalidate the newer separate media, and its PASS does not certify that newer movie.
- `AGENTS.md` retains an early source-import stage note. Source import and execution were subsequently demonstrated by the baseline and AWS evidence above. This packaging step leaves that historical instruction file unchanged.
- `docs/README_HISTORY_PRE_FINAL.md` preserves the exact previous README bytes, including its chronology and earlier wording.

Historical `NOT_RUN` values were not globally replaced. Live camera remains unverified; archived image analysis has run locally; AWS execution used synthetic or empty inputs. Human media approval, judge access and formal competition submission are tracked in the current companion review package.

## Changes made for this archive

Only three documentation paths differ from the input archive: the root README was rewritten for current readers; this status page was added; and the exact old README was added as a historical copy. Every other input file, including source, tests, requirements, Docker/workflow configuration, deployment.json and evidence, is byte-identical. The adjacent `source-provenance.json` records input and output archive hashes and the comparison results.
