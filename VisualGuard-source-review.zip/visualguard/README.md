# VisualGuard - Two views. One next step.

OpenCV 5 inspection on AWS, by **YOUNG-FU**. The prototype checks a front-and-side image pair and proposes **REVIEW**, **STOP**, or **REQUEST_VIEW**. An operator can provide a replacement pair and inspect again.

## Start here

This final-review archive preserves the program, tests and historical evidence from the prior local review candidate. The current status and companion movie are described in [Final review status](docs/FINAL_REVIEW_STATUS.md). Older source-import and prepared-video statements in checked-in records describe earlier checkpoints; they are not the current package summary.

| Work | Verified result |
| --- | --- |
| AWS execution | Private AWS_IAM Lambda in us-east-1; four recorded health, alarm, clear and empty-view invocations |
| Repository baseline | b85ebb0; existing hosted CI: 268 tests and 116 subtests passed |
| Local Windows candidate | 266 tests passed, 2 POSIX-only skips, 116 subtests passed; local portability changes not redeployed |
| Synthetic evaluation | 540 held-out pairs; 94.26% exact decisions; none of 210 alarm-containing cases returned REVIEW |
| Archived real-image exploration | 12 video frames plus 3 photos analysed locally; no red candidates; one crop of one photo also produced none; alarm accuracy unmeasured |
| Current film | Edited movie supplied separately in the final review package; combines archived footage, labelled generated illustration, application captures and saved AWS records |

Live-camera integration and physical equipment control are not demonstrated. The AWS image cases remain synthetic. All returned follow-ups are plans, with `action_executed=false`.

## Run the application

Use Python 3.12 and run from this extracted project directory:

```sh
python -m pip install -r requirements-vision.txt pytest==9.0.2
python -m service.app --host 127.0.0.1 --port 8080
```

Open `http://127.0.0.1:8080/`. Try the clear pair, side-only red indicator and occluded-front samples. Replace the occluded pair with a usable pair and inspect again.

For the included Windows review candidate, use a normal local PowerShell terminal and the helper that keeps SQLite and temporary files under `.local`:

```powershell
powershell -File ops/run_windows.ps1 -Action Serve -Python python -Port 8766
```

Then open `http://127.0.0.1:8766/`.

## Verify and reproduce

```sh
python -m pytest -q
python ops/verify_aws_recording.py
python ops/verify_judge_evidence_index.py
docker build --target http -t visualguard:http .
docker run --read-only --tmpfs /tmp -p 8080:8080 visualguard:http
```

Windows full suite: `powershell -File ops/run_windows.ps1 -Action Test -Python python`.
The two evidence verifiers read saved records and make no AWS calls. Deployment details are in the [AWS runbook](docs/AWS_DEPLOYMENT_RUNBOOK.md); replaying evidence does not require a new deployment.

## What is distinctive

Image quality changes the next step. OpenCV measures sharpness, exposure and occlusion, extracts red candidates with HSV masks and contour geometry, then combines both views. Metadata checks and a SQLite replay ledger support the workflow. The local HTTP app and private AWS Lambda share the inspection core; the replay ledger is per process or Lambda execution environment.

Known failures remain part of the evaluation: 30/30 round red stickers falsely return STOP, and one motion-blur case returns REVIEW instead of REQUEST_VIEW. The same-author synthetic generator does not establish field accuracy. The archived real-image check makes that validation gap concrete.

## Versions and supporting material

- Repository baseline: `b85ebb0873cf030ab95fd32c1d886df59bf74c86`.
- Actual AWS application source: `832b1b476ce88e3fa95e83ac5749f64af0f4bd63`.
- [Hosted CI run 40249719964](https://github.com/mangroveuniversemu-bot/visualguard-opencv-aws/actions/runs/40249719964).
- [AWS execution run 40223113044](https://github.com/mangroveuniversemu-bot/visualguard-opencv-aws/actions/runs/40223113044).
- [Architecture](docs/ARCHITECTURE.md), [synthetic technical record](docs/TECHNICAL_REPORT.md), [judge evidence index](docs/JUDGE_EVIDENCE_INDEX.md), [capture contract](docs/AWS_DEMO_CAPTURE_PACKET.md).
- [Current status and historical-record explanation](docs/FINAL_REVIEW_STATUS.md).
- [Preserved previous README](docs/README_HISTORY_PRE_FINAL.md).

The companion package supplies the updated technical report, final-review movie, real-image exploration records and judge guide. Judge access and final submission are completed through the owner handoff; this archive itself does not publish the service or change AWS permissions.
