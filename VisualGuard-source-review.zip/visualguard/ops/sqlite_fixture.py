"""Transaction-scoped SQLite fixtures that release Windows file handles."""

from contextlib import closing, contextmanager
import sqlite3


@contextmanager
def sqlite_fixture(*args, **kwargs):
    """Preserve commit/rollback semantics, then close on every exit path."""
    with closing(sqlite3.connect(*args, **kwargs)) as connection:
        with connection:
            yield connection
