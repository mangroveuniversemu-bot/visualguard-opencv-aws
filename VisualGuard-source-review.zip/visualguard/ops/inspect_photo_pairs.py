"""Optional local inspection of owner-provided photos; no AWS or camera calls."""

import argparse
import base64
from contextlib import redirect_stdout
import hashlib
from io import StringIO
import json
from pathlib import Path
import sys
import uuid

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))
from service.app import Service  # noqa: E402


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--manifest", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    manifest = json.loads(args.manifest.read_text(encoding="utf-8-sig"))
    cases = manifest.get("cases", [])
    if not cases:
        parser.error("Provide at least one owner-supplied photo pair; no example photos are fabricated.")
    out = args.output.resolve()
    out.parent.mkdir(parents=True, exist_ok=True)
    synthetic = manifest.get("source_kind") == "SYNTHETIC_FIXTURE"
    report = {"evidence_mode": "LOCAL_SYNTHETIC_IMPORTER_SMOKE" if synthetic else "LOCAL_OWNER_PROVIDED_PHOTO_SANITY_CHECK", "sensor_origin": "SYNTHETIC_FIXTURE" if synthetic else "OWNER_DECLARED_NOT_AUTHENTICATED", "aws_calls": 0, "cases": [], "limitations": ["Small exploratory sample, not field accuracy or sim-to-real validation.", "Capture freshness is server receive time; physical camera origin is not authenticated."]}
    with redirect_stdout(StringIO()):
        service = Service(out.parent / ("photo-check-" + uuid.uuid4().hex + ".sqlite3"))
        try:
            for case in cases:
                batch = uuid.uuid4().hex
                views, files = {}, {}
                for view in ("front", "side"):
                    path = (args.manifest.resolve().parent / case[view]).resolve()
                    raw = path.read_bytes()
                    files[view] = {"name": path.name, "sha256": hashlib.sha256(raw).hexdigest()}
                    views[view] = {"image_base64": base64.b64encode(raw).decode(), "source_id": f"camera-{view}-v1", "capture_id": f"{batch}-{view}"}
                status, _, payload = service.handle("POST", "/v1/inspect", json.dumps({"views": views}).encode())
                report["cases"].append({"name": case["name"], "owner_expected": case.get("expected", "UNLABELLED"), "inputs": files, "http_status": status, "response": json.loads(payload)})
        finally:
            service.close()
    out.write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
    print(f"Wrote {len(cases)} local photo checks to {out}. No AWS request was made.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
