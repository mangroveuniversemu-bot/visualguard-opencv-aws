"""Verify a pinned saved AWS evidence copy; never calls AWS or authenticates origin."""

import argparse
import hashlib
import json
from pathlib import Path

EXPECTED_SHA256 = "6f4d06d997b67be292e1cc9ad9febe6e59dddde7e661010e02da459e75d362b0"
SOURCE = "832b1b476ce88e3fa95e83ac5749f64af0f4bd63"


def verify(path):
    raw = Path(path).read_bytes()
    digest = hashlib.sha256(raw).hexdigest()
    if digest != EXPECTED_SHA256:
        raise ValueError("EVIDENCE_BYTES_MISMATCH")
    record = json.loads(raw)
    if record["source_commit"] != SOURCE:
        raise ValueError("SOURCE_MISMATCH")
    steps = record["deployment"]["steps"]
    calls = next(step["results"] for step in steps if step["step"] == "lambda_invocations")
    if calls["healthz"]["runtime"]["opencv_version"] != "5.0.0":
        raise ValueError("RUNTIME_MISMATCH")
    if (calls["inspect_alarm"]["decision"], calls["inspect_clear"]["decision"]) != ("STOP", "REVIEW"):
        raise ValueError("DECISION_MISMATCH")
    fourth = record["supplemental_negative_control"]["parsed_body"]
    if fourth["decision"] != "REQUEST_VIEW" or fourth["follow_up"]["action_executed"] is not False:
        raise ValueError("NEGATIVE_CONTROL_MISMATCH")
    reports = next(step["lines"] for step in steps if step["step"] == "cloudwatch_report_lines")
    if len(reports) != 3:
        raise ValueError("REPORT_COUNT_MISMATCH")
    return {"status": "PINNED_RECORDING_CONSISTENT", "sha256": digest,
            "recorded_invocations": 4, "aws_calls_made_by_verifier": 0,
            "origin_authentication": "NOT_A_DIGITAL_SIGNATURE",
            "scope": "Three workflow summaries and one full Console event/response; synthetic or empty input"}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--evidence", type=Path, default=Path(__file__).resolve().parents[1] / "evidence/AWS_EXECUTION_20261026_40223113044.json")
    args = parser.parse_args()
    try:
        print(json.dumps(verify(args.evidence), indent=2))
        return 0
    except (OSError, ValueError, KeyError, StopIteration) as error:
        print(json.dumps({"status": "REJECTED", "reason": str(error)}))
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
