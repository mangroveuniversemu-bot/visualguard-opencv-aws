param(
    [ValidateSet('Test', 'Serve')][string]$Action = 'Test',
    [string]$Python = 'python',
    [ValidateRange(1024, 65535)][int]$Port = 8766
)

# Keep SQLite and temporary files in the checkout's writable local directory.
# Run from a normal Windows terminal if a restricted runner blocks loopback.
$ErrorActionPreference = 'Stop'
$projectRoot = Split-Path -Parent $PSScriptRoot
$runtimeDirectory = Join-Path $projectRoot '.local'
$temporaryDirectory = Join-Path $runtimeDirectory 'windows-temp'
New-Item -ItemType Directory -Force -Path $temporaryDirectory | Out-Null
$previousTemp = $env:TEMP
$previousTmp = $env:TMP
$previousLedger = $env:VISUALGUARD_LEDGER_PATH
$resultCode = 0
Push-Location -LiteralPath $projectRoot
try {
    $env:TEMP = $temporaryDirectory
    $env:TMP = $temporaryDirectory
    $env:VISUALGUARD_LEDGER_PATH = Join-Path $runtimeDirectory 'capture-replay.sqlite3'
    if ($Action -eq 'Test') {
        & $Python -m pytest -q
    } else {
        & $Python -m service.app --host 127.0.0.1 --port $Port
    }
    $resultCode = $LASTEXITCODE
} finally {
    $env:TEMP = $previousTemp
    $env:TMP = $previousTmp
    $env:VISUALGUARD_LEDGER_PATH = $previousLedger
    Pop-Location
}
exit $resultCode
